import { useRef, useMemo, useState, useEffect, Component, type ReactNode } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Float, Sphere, Box, Points, PointMaterial } from '@react-three/drei';
import * as THREE from 'three';

function isWebGLAvailable() {
  try {
    const canvas = document.createElement('canvas');
    return !!(
      window.WebGLRenderingContext &&
      (canvas.getContext('webgl') || canvas.getContext('experimental-webgl'))
    );
  } catch {
    return false;
  }
}

class WebGLErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return null;
    }
    return this.props.children;
  }
}

function ParticleField() {
  const count = 2000;
  const positions = useMemo(() => {
    const p = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      p[i * 3] = (Math.random() - 0.5) * 20;
      p[i * 3 + 1] = (Math.random() - 0.5) * 20;
      p[i * 3 + 2] = (Math.random() - 0.5) * 20;
    }
    return p;
  }, [count]);

  const ref = useRef<THREE.Points>(null);

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y = state.clock.elapsedTime * 0.05;
      ref.current.rotation.x = state.clock.elapsedTime * 0.02;
    }
  });

  return (
    <Points ref={ref} positions={positions} stride={3} frustumCulled={false}>
      <PointMaterial
        transparent
        color="#00E5FF"
        size={0.05}
        sizeAttenuation={true}
        depthWrite={false}
        opacity={0.6}
        blending={THREE.AdditiveBlending}
      />
    </Points>
  );
}

function FloatingShapes() {
  const groupRef = useRef<THREE.Group>(null);
  const { mouse, viewport } = useThree();

  useFrame(() => {
    if (groupRef.current) {
      // Gentle mouse parallax
      const targetX = (mouse.x * viewport.width) / 10;
      const targetY = (mouse.y * viewport.height) / 10;
      groupRef.current.position.x += (targetX - groupRef.current.position.x) * 0.05;
      groupRef.current.position.y += (targetY - groupRef.current.position.y) * 0.05;
    }
  });

  return (
    <group ref={groupRef}>
      <Float speed={2} rotationIntensity={1} floatIntensity={2} position={[-4, 2, -5]}>
        <Sphere args={[1, 32, 32]}>
          <meshBasicMaterial color="#00E5FF" wireframe transparent opacity={0.3} />
        </Sphere>
      </Float>
      
      <Float speed={1.5} rotationIntensity={2} floatIntensity={1.5} position={[5, -2, -8]}>
        <Box args={[1.5, 1.5, 1.5]}>
          <meshBasicMaterial color="#5CE1FF" wireframe transparent opacity={0.4} />
        </Box>
      </Float>

      <Float speed={2.5} rotationIntensity={1.5} floatIntensity={2} position={[-5, -3, -6]}>
        <Box args={[1, 1, 1]}>
          <meshBasicMaterial color="#00E5FF" wireframe transparent opacity={0.2} />
        </Box>
      </Float>
      
      <Float speed={1} rotationIntensity={0.5} floatIntensity={1} position={[3, 3, -10]}>
        <Sphere args={[2, 16, 16]}>
          <meshBasicMaterial color="#00E5FF" transparent opacity={0.1} />
        </Sphere>
      </Float>
    </group>
  );
}

export function ThreeBackground() {
  const [webglOk, setWebglOk] = useState(false);

  useEffect(() => {
    setWebglOk(isWebGLAvailable());
  }, []);

  if (!webglOk) {
    return null;
  }

  return (
    <div className="absolute inset-0 z-0 pointer-events-none opacity-60 mix-blend-screen">
      <WebGLErrorBoundary>
        <Canvas camera={{ position: [0, 0, 5], fov: 60 }}>
          <fog attach="fog" args={['#05070A', 5, 15]} />
          <ambientLight intensity={0.5} />
          <ParticleField />
          <FloatingShapes />
        </Canvas>
      </WebGLErrorBoundary>
    </div>
  );
}
