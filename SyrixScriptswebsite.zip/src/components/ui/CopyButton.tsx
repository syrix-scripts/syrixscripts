import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Copy, Check } from 'lucide-react';
import { useToast } from '../../hooks/use-toast';

interface Ripple {
  id: number;
  x: number;
  y: number;
}

interface CopyButtonProps {
  value: string;
  label?: string;
  copiedLabel?: string;
  toastTitle?: string;
  toastDescription?: string;
  className?: string;
}

export function CopyButton({
  value,
  label = "Copy",
  copiedLabel = "Copied",
  toastTitle = "Copied!",
  toastDescription = "Copied to your clipboard.",
  className = "",
}: CopyButtonProps) {
  const [copied, setCopied] = useState(false);
  const [ripples, setRipples] = useState<Ripple[]>([]);
  const rippleId = useRef(0);
  const { toast } = useToast();

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const id = rippleId.current++;
    setRipples((prev) => [...prev, { id, x: e.clientX - rect.left, y: e.clientY - rect.top }]);
    setTimeout(() => {
      setRipples((prev) => prev.filter((r) => r.id !== id));
    }, 600);

    navigator.clipboard.writeText(value).then(() => {
      setCopied(true);
      toast({
        title: toastTitle,
        description: toastDescription,
        className: "bg-card border-primary text-white",
      });
      setTimeout(() => setCopied(false), 1600);
    });
  };

  return (
    <button
      onClick={handleClick}
      className={`relative overflow-hidden flex items-center justify-center gap-2 py-2.5 bg-primary/10 hover:bg-primary text-primary hover:text-black rounded-lg transition-colors duration-300 font-semibold text-sm border border-primary/20 hover:border-primary ${className}`}
    >
      {ripples.map((r) => (
        <motion.span
          key={r.id}
          initial={{ opacity: 0.5, scale: 0 }}
          animate={{ opacity: 0, scale: 4 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          style={{ left: r.x, top: r.y }}
          className="absolute w-4 h-4 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white/50 pointer-events-none"
        />
      ))}
      <AnimatePresence mode="wait" initial={false}>
        {copied ? (
          <motion.span
            key="check"
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.5, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="flex items-center gap-2"
          >
            <Check size={16} />
            {copiedLabel}
          </motion.span>
        ) : (
          <motion.span
            key="copy"
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.5, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="flex items-center gap-2"
          >
            <Copy size={16} />
            {label}
          </motion.span>
        )}
      </AnimatePresence>
    </button>
  );
}
