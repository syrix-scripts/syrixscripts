import { useState } from "react";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X } from "lucide-react";
import logoImage from "@assets/Screenshot_20260703-190543.Photos_1783087252874.png";

export function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navLinks = [
    { name: "Home", href: "#home" },
    { name: "Scripts", href: "#scripts" },
    { name: "Executors", href: "#executors" },
    { name: "Stats", href: "#stats" },
    { name: "FAQ", href: "#faq" },
  ];

  const handleNavClick = (href: string) => {
    setIsMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b-0 border-white/5 transition-all duration-300 py-3">
      <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3 group">
          <div className="w-10 h-10 relative overflow-hidden rounded-lg">
            <img 
              src={logoImage} 
              alt="Logo" 
              className="w-full h-full object-cover scale-150 group-hover:scale-110 transition-transform duration-500"
            />
          </div>
          <span className="text-xl font-bold tracking-tight text-white group-hover:text-primary transition-colors">
            SYRIX<span className="text-primary glow-text">SCRIPTS</span>
          </span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.name}
              onClick={() => handleNavClick(link.href)}
              className="text-sm font-medium text-white/70 hover:text-white relative group"
            >
              {link.name}
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-primary transition-all duration-300 group-hover:w-full glow-border" />
            </button>
          ))}
          <button className="px-5 py-2 rounded-full bg-primary/10 text-primary border border-primary/30 hover:bg-primary hover:text-black transition-all duration-300 font-semibold text-sm glow-border">
            Join Discord
          </button>
        </div>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-white/70 hover:text-white p-2"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden glass-card mt-3 mx-4 rounded-xl overflow-hidden"
          >
            <div className="flex flex-col p-4 gap-4">
              {navLinks.map((link) => (
                <button
                  key={link.name}
                  onClick={() => handleNavClick(link.href)}
                  className="text-left text-white/70 hover:text-primary font-medium py-2 px-4 rounded-lg hover:bg-white/5 transition-colors"
                >
                  {link.name}
                </button>
              ))}
              <button className="w-full py-3 mt-2 rounded-lg bg-primary/10 text-primary border border-primary/30 hover:bg-primary hover:text-black transition-all font-semibold glow-border">
                Join Discord
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
