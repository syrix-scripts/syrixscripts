import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="relative border-t border-primary/20 bg-background/80 backdrop-blur-lg pt-16 pb-8 overflow-hidden">
      {/* Glow effect */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/2 h-[1px] bg-gradient-to-r from-transparent via-primary to-transparent opacity-50 blur-[2px]" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <Link href="/" className="flex items-center gap-3 mb-6">
              <span className="text-2xl font-bold text-white">
                SYRIX<span className="text-primary glow-text">SCRIPTS</span>
              </span>
            </Link>
            <p className="text-muted-foreground max-w-sm mb-6 leading-relaxed">
              The ultimate premium Roblox script library. Providing top-tier, secure, and constantly updated execution scripts to the community.
            </p>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {["Scripts", "Executors", "Submit Script", "API Documentation"].map(link => (
                <li key={link}>
                  <a href="#" className="text-muted-foreground hover:text-primary transition-colors text-sm">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="text-white font-semibold mb-6">Legal</h4>
            <ul className="space-y-3">
              {["Terms of Service", "Privacy Policy", "DMCA Disclaimer", "Contact Us"].map(link => (
                <li key={link}>
                  <a href="#" className="text-muted-foreground hover:text-primary transition-colors text-sm">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            © 2026 SyrixScripts. All Rights Reserved.
          </p>
          <p className="text-xs text-muted-foreground/50">
            Not affiliated with Roblox Corporation.
          </p>
        </div>
      </div>
    </footer>
  );
}
