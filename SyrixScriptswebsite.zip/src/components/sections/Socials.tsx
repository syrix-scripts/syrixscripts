import { motion } from 'framer-motion';
import { socialsData } from '../../lib/data';
import { CopyButton } from '../ui/CopyButton';
import { SectionHeading } from '../ui/SectionHeading';

const YouTubeIcon = ({ size = 32, className = "" }: { size?: number; className?: string }) => (
  <svg viewBox="0 0 24 24" width={size} height={size} className={className} fill="currentColor">
    <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
  </svg>
);

const DiscordIcon = ({ size = 32, className = "" }: { size?: number; className?: string }) => (
  <svg viewBox="0 0 24 24" width={size} height={size} className={className} fill="currentColor">
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037 19.736 19.736 0 0 0-4.885 1.515.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.673-3.548-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.955 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
  </svg>
);

export function Socials() {
  const iconMap: Record<string, (props: { size?: number; className?: string }) => React.ReactElement> = {
    YouTube: YouTubeIcon,
    Discord: DiscordIcon,
  };

  const styleMap: Record<string, { color: string; textColor: string }> = {
    YouTube: {
      color: "hover:border-[#FF0000] hover:shadow-[0_0_25px_rgba(255,0,0,0.4)]",
      textColor: "group-hover:text-[#FF0000]",
    },
    Discord: {
      color: "hover:border-[#5865F2] hover:shadow-[0_0_25px_rgba(88,101,242,0.4)]",
      textColor: "group-hover:text-[#5865F2]",
    },
  };

  return (
    <section className="py-24 relative z-10 bg-background/50">
      <div className="container mx-auto px-4 md:px-6">
        <SectionHeading
          eyebrow="Community"
          title={<>Join The <span className="text-primary glow-text">Community</span></>}
          subtitle="Follow along for updates, showcases, and support from other members."
        />

        <div className="flex flex-wrap justify-center gap-6 max-w-4xl mx-auto">
          {socialsData.map((social, idx) => {
            const Icon = iconMap[social.name];
            const style = styleMap[social.name];
            return (
              <motion.div
                key={social.name}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: idx * 0.1 }}
                whileHover={{ y: -6, scale: 1.03 }}
                className={`group relative flex items-center gap-4 px-8 py-6 glass-card rounded-2xl transition-all duration-300 ${style.color}`}
              >
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                <motion.div whileHover={{ rotate: 12 }} transition={{ type: "spring", stiffness: 300 }}>
                  <Icon size={32} className={`text-muted-foreground transition-colors duration-300 ${style.textColor}`} />
                </motion.div>
                <a
                  href={social.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`text-xl font-bold text-white transition-colors duration-300 ${style.textColor}`}
                >
                  {social.name}
                </a>
                <CopyButton
                  value={social.link}
                  label=""
                  copiedLabel=""
                  className="!py-2 !px-3 !bg-transparent !border-white/10 hover:!border-primary/50"
                  toastTitle="Link Copied!"
                  toastDescription={`${social.name} link copied to your clipboard.`}
                />
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
