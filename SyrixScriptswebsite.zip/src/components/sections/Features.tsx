import { motion } from 'framer-motion';
import { featuresData } from '../../lib/data';
import { Zap, Shield, Laptop, Search, Gem, Layout, Clock, Users, type LucideIcon } from 'lucide-react';

const iconMap: Record<string, LucideIcon> = {
  "Responsive": Laptop,
  "Lightning Fast": Zap,
  "Secure": Shield,
  "Modern Glass UI": Layout,
  "Live Search": Search,
  "Premium Design": Gem,
  "Daily Updates": Clock,
  "Community Driven": Users
};

export function Features() {
  return (
    <section className="py-24 relative z-10 bg-background/80">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-5xl font-bold mb-4 text-white"
          >
            Why Choose <span className="text-primary glow-text">SyrixScripts</span>
          </motion.h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Built from the ground up to provide a seamless, premium experience unlike any other script hub.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuresData.map((feature, idx) => {
            const Icon = iconMap[feature.title] || Shield;
            
            return (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.4, delay: idx * 0.05 }}
                key={feature.title}
                className="glass-card rounded-xl p-6 group hover:-translate-y-2 transition-transform duration-300"
              >
                <div className="w-12 h-12 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center text-primary mb-4 group-hover:scale-110 group-hover:bg-primary group-hover:text-black transition-all duration-300 shadow-[0_0_15px_rgba(0,229,255,0)] group-hover:shadow-[0_0_15px_rgba(0,229,255,0.4)]">
                  <Icon size={24} />
                </div>
                <h3 className="text-lg font-bold text-white mb-2 group-hover:text-primary transition-colors">
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {feature.desc}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
