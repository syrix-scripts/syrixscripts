import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Terminal, ExternalLink, Search } from 'lucide-react';
import { executorsData } from '../../lib/data';
import { CopyButton } from '../ui/CopyButton';
import { SectionHeading } from '../ui/SectionHeading';

const PLATFORMS = ["All", "Windows", "Android", "Android / iOS", "Android / Windows"];

export function ExecutorsShowcase() {
  const [searchTerm, setSearchTerm] = useState("");
  const [platform, setPlatform] = useState("All");

  const filteredExecutors = useMemo(() => {
    return executorsData.filter((executor) => {
      const matchesSearch = executor.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesPlatform = platform === "All" || executor.platform === platform;
      return matchesSearch && matchesPlatform;
    });
  }, [searchTerm, platform]);

  return (
    <section id="executors" className="py-24 relative z-10 bg-background/50 border-y border-white/5">
      <div className="absolute inset-0 bg-noise opacity-30 pointer-events-none" />

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <SectionHeading
          eyebrow="Executors Library"
          title={<>Recommended <span className="text-primary glow-text">Executors</span></>}
          subtitle="Pair our scripts with the most reliable executors on the market. Real links to official sites, verified daily."
        />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-10">
          <div className="flex flex-wrap gap-2">
            {PLATFORMS.map((p) => (
              <button
                key={p}
                onClick={() => setPlatform(p)}
                className={`px-4 py-2 rounded-lg text-xs font-semibold border transition-all duration-300 ${
                  platform === p
                    ? "bg-primary text-black border-primary shadow-[0_0_15px_rgba(0,229,255,0.4)]"
                    : "bg-white/5 text-white/60 border-white/10 hover:border-primary/40 hover:text-white"
                }`}
              >
                {p}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-64">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={16} className="text-muted-foreground" />
            </div>
            <input
              type="text"
              placeholder="Search executors..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 pl-9 pr-4 text-white text-sm focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/50 transition-all placeholder:text-white/30 glass-card"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredExecutors.map((executor, idx) => (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: (idx % 6) * 0.08 }}
              whileHover={{ y: -6 }}
              key={executor.id}
              className="glass-card rounded-2xl p-1 relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-primary/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl pointer-events-none" />

              <div className="relative z-10 bg-card/80 backdrop-blur-xl h-full rounded-xl p-6 flex flex-col">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-300">
                      <Terminal size={24} />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-white group-hover:text-primary transition-colors">
                        {executor.name}
                      </h3>
                      <p className="text-xs text-white/50">{executor.platform}</p>
                    </div>
                  </div>
                  {executor.isExample && (
                    <span className="px-2 py-1 rounded text-[9px] font-bold uppercase bg-white/5 text-white/40 border border-white/10">
                      Example
                    </span>
                  )}
                </div>

                <p className="text-sm text-muted-foreground mb-6 flex-grow">
                  {executor.description}
                </p>

                <div className="flex items-center justify-between text-sm font-medium mb-6">
                  <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider ${
                    executor.status === 'Working' ? 'bg-green-500/20 text-green-400 border border-green-500/30' :
                    executor.status === 'Updated' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
                    executor.status === 'Patching' ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30' :
                    'bg-red-500/20 text-red-400 border border-red-500/30'
                  }`}>
                    {executor.status}
                  </span>
                  <span className="text-white/70">Rating: <span className="text-yellow-400">{executor.rating}★</span></span>
                </div>

                <div className="flex gap-3">
                  <a
                    href={executor.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-white/5 hover:bg-primary/20 text-white hover:text-primary rounded-lg transition-all duration-300 font-semibold text-sm border border-white/10 hover:border-primary/50 group-hover:shadow-[0_0_15px_rgba(0,229,255,0.2)]"
                  >
                    <ExternalLink size={16} />
                    Website
                  </a>
                  <CopyButton
                    value={executor.website}
                    label="Copy"
                    className="flex-1 text-sm"
                    toastTitle="Link Copied!"
                    toastDescription={`${executor.name}'s website link was copied.`}
                  />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {filteredExecutors.length === 0 && (
          <div className="w-full py-20 flex flex-col items-center justify-center text-muted-foreground">
            <Search size={48} className="mb-4 opacity-20" />
            <p>No executors found matching your search.</p>
          </div>
        )}
      </div>
    </section>
  );
}
