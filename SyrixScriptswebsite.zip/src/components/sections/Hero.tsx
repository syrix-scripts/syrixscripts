import { motion } from 'framer-motion';
import { ChevronRight, Play, Download, Zap } from 'lucide-react';
import { ThreeBackground } from '../ThreeBackground';

export function Hero() {
  return (
    <section id="home" className="relative min-h-[100dvh] flex items-center justify-center pt-20 overflow-hidden bg-background">
      <ThreeBackground />
      
      {/* Background gradients */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-1/4 left-1/4 w-[400px] h-[400px] bg-blue-500/20 rounded-full blur-[100px] pointer-events-none" />

      <div className="container relative z-10 mx-auto px-4 flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass-card mb-8 border border-primary/30"
        >
          <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
          <span className="text-xs font-medium text-primary tracking-wider uppercase">SyrixScripts v4.0 is Live</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.4, type: "spring" }}
          className="text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter mb-6 text-white"
        >
          SYRIX<span className="text-primary glow-text">SCRIPTS</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-lg md:text-2xl text-muted-foreground max-w-2xl mx-auto mb-12 font-medium"
        >
          The Ultimate Premium Roblox Script Library. Dominate your favorite games with high-tier, secure execution.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="flex flex-wrap items-center justify-center gap-4 w-full max-w-3xl"
        >
          <button className="interactive group relative px-8 py-4 bg-primary text-black font-bold rounded-xl overflow-hidden hover:scale-105 transition-all duration-300 shadow-[0_0_20px_rgba(0,229,255,0.4)] hover:shadow-[0_0_30px_rgba(0,229,255,0.6)]">
            <div className="absolute inset-0 bg-white/20 translate-y-[-100%] group-hover:translate-y-[100%] transition-transform duration-500" />
            <span className="flex items-center gap-2 relative z-10">
              <Zap size={20} className="fill-black" />
              Explore Scripts
            </span>
          </button>
          
          <button className="interactive group px-8 py-4 glass-card text-white font-bold rounded-xl hover:bg-white/10 hover:border-primary/50 transition-all duration-300">
            <span className="flex items-center gap-2">
              <Download size={20} className="text-primary" />
              Executors
            </span>
          </button>
          
          <button className="interactive group px-8 py-4 glass-card text-white font-bold rounded-xl hover:bg-white/10 hover:border-primary/50 transition-all duration-300">
            <span className="flex items-center gap-2">
              <img src="https://cdn.simpleicons.org/discord/white" alt="Discord" className="w-5 h-5 group-hover:text-primary" />
              Join Discord
            </span>
          </button>

          <button className="interactive group px-8 py-4 glass-card text-white font-bold rounded-xl hover:bg-white/10 hover:border-primary/50 transition-all duration-300">
            <span className="flex items-center gap-2">
              <Play size={20} className="text-red-500" />
              Watch on YouTube
            </span>
          </button>
        </motion.div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center animate-bounce">
        <span className="text-xs text-muted-foreground uppercase tracking-widest mb-2">Scroll</span>
        <ChevronRight size={20} className="text-primary rotate-90" />
      </div>
    </section>
  );
}
