import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, ExternalLink, ShieldCheck, Clock } from 'lucide-react';
import { scriptsData } from '../../lib/data';
import { CopyButton } from '../ui/CopyButton';
import { SectionHeading } from '../ui/SectionHeading';
import { MoreScripts } from './MoreScripts';

const CATEGORIES = ["All", "Universal", "Blox Fruits", "Auto Farm", "ESP", "Aimbot"];

function highlightMatch(text: string, term: string) {
  if (!term.trim()) return text;
  const parts = text.split(new RegExp(`(${term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi'));
  return parts.map((part, i) =>
    part.toLowerCase() === term.toLowerCase() ? (
      <mark key={i} className="bg-primary/30 text-primary rounded px-0.5">{part}</mark>
    ) : (
      <span key={i}>{part}</span>
    )
  );
}

export function ScriptsShowcase() {
  const [searchTerm, setSearchTerm] = useState("");
  const [category, setCategory] = useState("All");

  const filteredScripts = useMemo(() => {
    return scriptsData.filter((script) => {
      const matchesSearch =
        script.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        script.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase())) ||
        script.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = category === "All" || script.tags.includes(category);
      return matchesSearch && matchesCategory;
    });
  }, [searchTerm, category]);

  return (
    <section id="scripts" className="py-24 relative z-10 bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <SectionHeading
          eyebrow="Script Library"
          title={<>Premium <span className="text-primary glow-text">Scripts</span></>}
          subtitle="Access the most powerful, secure, and undetected scripts on the market. Constantly updated and community verified."
        />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-10">
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`px-4 py-2 rounded-lg text-xs font-semibold border transition-all duration-300 ${
                  category === cat
                    ? "bg-primary text-black border-primary shadow-[0_0_15px_rgba(0,229,255,0.4)]"
                    : "bg-white/5 text-white/60 border-white/10 hover:border-primary/40 hover:text-white"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-72">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={18} className="text-muted-foreground" />
            </div>
            <input
              type="text"
              placeholder="Search scripts..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded-xl py-3 pl-10 pr-4 text-white focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/50 transition-all placeholder:text-white/30 glass-card"
            />
          </div>
        </div>

        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6"
        >
          <AnimatePresence>
            {filteredScripts.map((script, idx) => (
              <motion.div
                layout
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4, delay: idx * 0.08 }}
                viewport={{ once: true, margin: "-50px" }}
                whileHover={{ y: -6 }}
                key={script.id}
                className="glass-card rounded-2xl p-6 group relative overflow-hidden flex flex-col h-full"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

                <div className="flex justify-between items-start mb-4 relative z-10">
                  <h3 className="text-xl font-bold text-white group-hover:text-primary transition-colors">
                    {highlightMatch(script.name, searchTerm)}
                  </h3>
                  <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider ${
                    script.status === 'Working' ? 'bg-green-500/20 text-green-400 border border-green-500/30' :
                    script.status === 'Updated' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
                    'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                  }`}>
                    {script.status}
                  </span>
                </div>

                <div className="flex gap-2 mb-4 relative z-10 flex-wrap">
                  {script.tags.map(tag => (
                    <span key={tag} className="text-xs px-2 py-1 bg-white/5 rounded-md text-white/60 border border-white/5">
                      {highlightMatch(tag, searchTerm)}
                    </span>
                  ))}
                </div>

                <p className="text-sm text-muted-foreground mb-6 flex-grow relative z-10">
                  {highlightMatch(script.description, searchTerm)}
                </p>

                <div className="flex items-center justify-between text-xs text-white/40 mb-6 relative z-10">
                  <div className="flex items-center gap-1">
                    <ShieldCheck size={14} className="text-primary" />
                    {script.version}
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock size={14} className="text-primary" />
                    {script.updatedAt}
                  </div>
                </div>

                <div className="flex gap-3 relative z-10 mt-auto">
                  <CopyButton
                    value={`-- ${script.name} (placeholder)\n-- Replace with your real script source.`}
                    className="flex-1"
                    toastTitle="Script Copied!"
                    toastDescription={`${script.name} has been copied to your clipboard.`}
                  />
                  <button className="flex-1 flex items-center justify-center gap-2 py-2.5 glass bg-white/5 hover:bg-white/10 text-white rounded-lg transition-all duration-300 font-semibold text-sm border border-white/10 hover:border-primary/50">
                    <ExternalLink size={16} />
                    Details
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {filteredScripts.length === 0 && (
          <div className="w-full py-20 flex flex-col items-center justify-center text-muted-foreground">
            <Search size={48} className="mb-4 opacity-20" />
            <p>No scripts found matching your search.</p>
          </div>
        )}

        <MoreScripts />
      </div>
    </section>
  );
}
