import { useState, useMemo, useCallback } from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, Clock } from 'lucide-react';
import { moreScriptsData } from '../../lib/data';
import { CopyButton } from '../ui/CopyButton';

const PAGE_SIZE = 6;

export function MoreScripts() {
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);

  const visibleScripts = useMemo(() => moreScriptsData.slice(0, visibleCount), [visibleCount]);
  const hasMore = visibleCount < moreScriptsData.length;

  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    const el = e.currentTarget;
    if (!hasMore) return;
    if (el.scrollHeight - el.scrollTop - el.clientHeight < 120) {
      setVisibleCount((prev) => Math.min(prev + PAGE_SIZE, moreScriptsData.length));
    }
  }, [hasMore]);

  return (
    <div className="mt-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="flex items-center justify-between mb-6"
      >
        <h3 className="text-2xl md:text-3xl font-bold text-white">
          More <span className="text-primary glow-text">Blox Fruits Scripts</span>
        </h3>
        <span className="text-xs text-white/40 uppercase tracking-wider">
          {visibleScripts.length} / {moreScriptsData.length} loaded
        </span>
      </motion.div>

      <div
        onScroll={handleScroll}
        className="glass rounded-3xl p-4 md:p-6 max-h-[520px] overflow-y-auto relative"
      >
        <div className="absolute top-0 left-0 right-0 h-8 bg-gradient-to-b from-background/80 to-transparent pointer-events-none z-10 rounded-t-3xl" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {visibleScripts.map((script, idx) => (
            <motion.div
              key={script.id}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.35, delay: (idx % PAGE_SIZE) * 0.05 }}
              whileHover={{ y: -4 }}
              className="glass-card rounded-xl p-4 flex flex-col relative overflow-hidden group"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
              <div className="flex justify-between items-start mb-2 relative z-10">
                <h4 className="font-bold text-white group-hover:text-primary transition-colors text-sm">
                  {script.name}
                </h4>
                <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wide ${
                  script.status === 'Working' ? 'bg-green-500/20 text-green-400 border border-green-500/30' :
                  script.status === 'Updated' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
                  'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                }`}>
                  {script.status}
                </span>
              </div>
              <p className="text-xs text-muted-foreground mb-3 flex-grow relative z-10 line-clamp-2">
                {script.description}
              </p>
              <div className="flex items-center justify-between text-[10px] text-white/40 mb-3 relative z-10">
                <div className="flex items-center gap-1">
                  <ShieldCheck size={12} className="text-primary" />
                  {script.version}
                </div>
                <div className="flex items-center gap-1">
                  <Clock size={12} className="text-primary" />
                  {script.updatedAt}
                </div>
              </div>
              <CopyButton
                value={`-- ${script.name} (placeholder)\n-- Replace with your real script source.`}
                className="w-full py-2 text-xs relative z-10"
                toastTitle="Copied!"
                toastDescription={`${script.name} placeholder copied to your clipboard.`}
              />
            </motion.div>
          ))}
        </div>

        {hasMore && (
          <div className="flex justify-center pt-6">
            <motion.div
              className="flex gap-1.5"
              initial="hidden"
              animate="visible"
            >
              {[0, 1, 2].map((i) => (
                <motion.span
                  key={i}
                  className="w-2 h-2 rounded-full bg-primary/60"
                  animate={{ opacity: [0.3, 1, 0.3], scale: [0.8, 1.1, 0.8] }}
                  transition={{ duration: 1, repeat: Infinity, delay: i * 0.15 }}
                />
              ))}
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
}
