import { useEffect, useState, useRef } from 'react';
import { motion, useInView } from 'framer-motion';

const AnimatedCounter = ({ value, label, suffix = "" }: { value: number, label: string, suffix?: string }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (isInView) {
      let start = 0;
      const duration = 2000;
      const startTime = performance.now();

      const animate = (currentTime: number) => {
        const elapsedTime = currentTime - startTime;
        const progress = Math.min(elapsedTime / duration, 1);
        
        // Easing function: easeOutQuart
        const easeOut = 1 - Math.pow(1 - progress, 4);
        
        setCount(Math.floor(easeOut * value));

        if (progress < 1) {
          requestAnimationFrame(animate);
        }
      };

      requestAnimationFrame(animate);
    }
  }, [isInView, value]);

  return (
    <div ref={ref} className="text-center">
      <div className="text-4xl md:text-6xl font-black text-white mb-2 flex items-center justify-center font-mono tracking-tighter">
        {count.toLocaleString()}{suffix}
      </div>
      <div className="text-sm md:text-base text-primary uppercase tracking-widest font-semibold glow-text">
        {label}
      </div>
    </div>
  );
};

export function Stats() {
  return (
    <section id="stats" className="py-20 relative z-10 bg-black overflow-hidden border-y border-white/5">
      {/* Aurora glow effect */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-[150%] bg-gradient-to-r from-primary/10 via-blue-500/10 to-primary/10 blur-[100px] pointer-events-none" />
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12">
          <AnimatedCounter value={750} label="Active Scripts" suffix="+" />
          <AnimatedCounter value={120} label="Executors" suffix="+" />
          <AnimatedCounter value={250} label="Downloads" suffix="K+" />
          <AnimatedCounter value={99.9} label="Uptime" suffix="%" />
        </div>
      </div>
    </section>
  );
}
