import { Hero } from '../components/sections/Hero';
import { ScriptsShowcase } from '../components/sections/ScriptsShowcase';
import { ExecutorsShowcase } from '../components/sections/ExecutorsShowcase';
import { Stats } from '../components/sections/Stats';
import { ChartsSection } from '../components/sections/ChartsSection';
import { Features } from '../components/sections/Features';
import { Faq } from '../components/sections/Faq';
import { Socials } from '../components/sections/Socials';
import { SectionHeading } from '../components/ui/SectionHeading';

export function Home() {
  return (
    <main className="min-h-screen bg-background text-foreground flex flex-col selection:bg-primary/30 selection:text-white">
      <Hero />

      <div id="scripts-section" className="relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-[1px] bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
        <ScriptsShowcase />
      </div>

      <div id="executors-section" className="relative">
        <ExecutorsShowcase />
      </div>

      <section id="resources-section" className="py-24 relative z-10 bg-background">
        <div className="container mx-auto px-4 md:px-6">
          <SectionHeading
            eyebrow="Resources"
            title={<>The <span className="text-primary glow-text">Resources</span> Hub</>}
            subtitle="Everything else you need — live stats, growth data, platform features, answers, and where to find us."
          />
        </div>
        <Stats />
        <ChartsSection />
        <Features />
        <Faq />
        <Socials />
      </section>
    </main>
  );
}
