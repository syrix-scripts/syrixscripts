export const scriptsData = [
  {
    id: "1",
    name: "Aura Hub",
    description: "The most powerful universal script hub for over 50+ games with premium bypasses.",
    status: "Working",
    version: "v3.2.1",
    rating: 4.9,
    downloads: "125K+",
    tags: ["Universal", "Keyless", "OP"],
    updatedAt: "2h ago",
  },
  {
    id: "2",
    name: "Blade X",
    description: "Premium auto-farm and PvP features specifically built for Blade Ball.",
    status: "Working",
    version: "v1.4.0",
    rating: 4.8,
    downloads: "89K+",
    tags: ["Auto Farm", "PvP"],
    updatedAt: "5h ago",
  },
  {
    id: "3",
    name: "Nexus Blox",
    description: "Advanced Blox Fruits script featuring auto-parry, chest farm, and ESP.",
    status: "Working",
    version: "v2.1.5",
    rating: 4.7,
    downloads: "210K+",
    tags: ["Blox Fruits", "ESP"],
    updatedAt: "1d ago",
  },
  {
    id: "4",
    name: "Phantom Forces ESP",
    description: "Undetected ESP, Aimbot, and silent aim for Phantom Forces. Safe for mains.",
    status: "Updated",
    version: "v4.0.2",
    rating: 4.5,
    downloads: "45K+",
    tags: ["FPS", "Aimbot", "Safe"],
    updatedAt: "3d ago",
  },
  {
    id: "5",
    name: "Adopt Me Pro",
    description: "Auto-neon, auto-farm, and trade scam prevention overlay.",
    status: "Working",
    version: "v1.9.9",
    rating: 4.6,
    downloads: "150K+",
    tags: ["Auto Neon", "Utility"],
    updatedAt: "12h ago",
  },
  {
    id: "6",
    name: "Da Hood Legends",
    description: "God mode, cash farm, and lock-on aimbot with custom resolver.",
    status: "Working",
    version: "v2.0.0",
    rating: 4.8,
    downloads: "75K+",
    tags: ["Aimbot", "Farm"],
    updatedAt: "2d ago",
  },
  {
    id: "7",
    name: "Jailbreak Admin",
    description: "Auto-rob every store, infinite nitro, and cop ESP bypass.",
    status: "Patching",
    version: "v3.5.1",
    rating: 4.2,
    downloads: "190K+",
    tags: ["Auto Rob", "Admin"],
    updatedAt: "1w ago",
  },
  {
    id: "8",
    name: "Murder Mystery V",
    description: "Coin farmer, sheriff ESP, murderer ESP, and instant win.",
    status: "Working",
    version: "v1.1.0",
    rating: 4.9,
    downloads: "60K+",
    tags: ["ESP", "Farm"],
    updatedAt: "4h ago",
  },
];

export const executorsData = [
  {
    id: "e1",
    name: "Delta",
    platform: "Android",
    status: "Working",
    website: "https://deltaexploits.gg",
    type: "Free",
    rating: 4.5,
    description: "Number one mobile executor. Smooth UI and great execution.",
    isExample: false,
  },
  {
    id: "e2",
    name: "Volt",
    platform: "Windows",
    status: "Working",
    website: "https://volt.bz/",
    type: "Free",
    rating: 4.4,
    description: "Fast and lightweight executor built for reliability.",
    isExample: false,
  },
  {
    id: "e3",
    name: "Xeno",
    platform: "Android / iOS",
    status: "Working",
    website: "https://xeno.now/",
    type: "Free",
    rating: 4.6,
    description: "Cross-platform mobile executor with a growing feature set.",
    isExample: false,
  },
  {
    id: "e4",
    name: "Madium",
    platform: "Windows",
    status: "Working",
    website: "https://getmadium.net/",
    type: "Free",
    rating: 4.3,
    description: "Modern executor focused on clean UI and script compatibility.",
    isExample: false,
  },
  {
    id: "e5",
    name: "Wave",
    platform: "Windows",
    status: "Working",
    website: "#",
    type: "Free",
    rating: 4.6,
    description: "Powerful free executor with high script compatibility.",
    isExample: true,
  },
  {
    id: "e6",
    name: "Solara",
    platform: "Windows",
    status: "Working",
    website: "#",
    type: "Free",
    rating: 4.5,
    description: "Community favorite with a simple, distraction-free UI.",
    isExample: true,
  },
  {
    id: "e7",
    name: "Swift",
    platform: "Android",
    status: "Updated",
    website: "#",
    type: "Free",
    rating: 4.2,
    description: "Lightweight mobile executor built for speed.",
    isExample: true,
  },
  {
    id: "e8",
    name: "Velocity",
    platform: "Windows",
    status: "Working",
    website: "#",
    type: "Premium",
    rating: 4.4,
    description: "Premium execution with advanced debugging tools.",
    isExample: true,
  },
  {
    id: "e9",
    name: "Codex",
    platform: "Android / iOS",
    status: "Working",
    website: "#",
    type: "Free",
    rating: 4.4,
    description: "Cross-platform mobile executor with a built-in script hub.",
    isExample: true,
  },
  {
    id: "e10",
    name: "Hydrogen",
    platform: "Android / iOS",
    status: "Working",
    website: "#",
    type: "Free",
    rating: 4.3,
    description: "Mobile-first executor with a large community following.",
    isExample: true,
  },
  {
    id: "e11",
    name: "Electron",
    platform: "Windows",
    status: "Patching",
    website: "#",
    type: "Free",
    rating: 4.0,
    description: "Community-maintained executor with frequent updates.",
    isExample: true,
  },
  {
    id: "e12",
    name: "Arceus X",
    platform: "Android",
    status: "Working",
    website: "#",
    type: "Free",
    rating: 4.5,
    description: "Long-standing mobile executor with a large plugin library.",
    isExample: true,
  },
  {
    id: "e13",
    name: "KRNL",
    platform: "Windows",
    status: "Offline",
    website: "#",
    type: "Free",
    rating: 4.1,
    description: "One of the most recognized free-tier executors.",
    isExample: true,
  },
  {
    id: "e14",
    name: "Fluxus",
    platform: "Android / Windows",
    status: "Working",
    website: "#",
    type: "Free",
    rating: 4.3,
    description: "Cross-platform executor with a friendly script hub.",
    isExample: true,
  },
];

export const moreScriptsData = Array.from({ length: 18 }, (_, i) => {
  const idx = i + 1;
  const statuses = ["Working", "Updated", "Patching"];
  const tags = [
    ["Auto Farm", "ESP"],
    ["Auto Parry", "Fruit Notifier"],
    ["Raid Farm", "Boss ESP"],
    ["Trading", "Stat Tracker"],
    ["Fly", "Speed"],
    ["Chest Farm", "Devil Fruit"],
  ];
  return {
    id: `more-${idx}`,
    name: `Example Hub ${idx}`,
    description: "Placeholder Blox Fruits script hub. Swap this card with a real listing whenever you're ready.",
    status: statuses[i % statuses.length],
    version: `v${(i % 4) + 1}.${(i % 9)}.0`,
    rating: Number((4 + Math.random() * 0.9).toFixed(1)),
    downloads: `${(i + 1) * 3}K+`,
    tags: tags[i % tags.length],
    updatedAt: `${(i % 12) + 1}h ago`,
  };
});

export const featuresData = [
  { title: "Responsive", desc: "Flawless experience across desktop, tablet, and mobile devices." },
  { title: "Lightning Fast", desc: "Optimized delivery network ensures zero latency on downloads." },
  { title: "Secure", desc: "All scripts are verified and tested against malicious code." },
  { title: "Modern Glass UI", desc: "Aesthetically pleasing interface designed for late-night gaming." },
  { title: "Live Search", desc: "Find exactly what you need in milliseconds with our fuzzy search." },
  { title: "Premium Design", desc: "No clutter, no intrusive ads. Just pure, clean execution." },
  { title: "Daily Updates", desc: "Our database is refreshed every hour to ensure scripts work." },
  { title: "Community Driven", desc: "Ratings and reviews powered by over 50,000 active members." },
];

export const faqData = [
  {
    q: "What is SyrixScripts?",
    a: "A modern platform that organizes Roblox scripting resources in a clean, easy-to-browse interface."
  },
  {
    q: "How do I copy a script?",
    a: "Simply press the Copy button and the script will be copied instantly to your clipboard, ready to paste into your executor."
  },
  {
    q: "Why are executors listed?",
    a: "The website provides quick access to official executor websites for convenience, so you always know where to get the tools you need."
  },
  {
    q: "How often is the library updated?",
    a: "New scripts and resources are added regularly whenever available, and statuses are refreshed to reflect what's currently working."
  },
  {
    q: "Can I suggest a script?",
    a: "Future versions will include community suggestions, letting members recommend scripts and hubs to be featured."
  },
  {
    q: "Does SyrixScripts create scripts?",
    a: "No. The website serves as an organized directory of publicly shared resources, not a script development team."
  },
  {
    q: "Is the website mobile friendly?",
    a: "Yes. Every page is fully responsive and designed to work smoothly across desktop, tablet, and mobile devices."
  },
  {
    q: "Will more games be supported?",
    a: "Future updates may expand beyond Blox Fruits to cover more of the Roblox ecosystem."
  },
  {
    q: "Is there a Discord community?",
    a: "Yes. Join using the Discord button in the socials section to connect with other members."
  },
  {
    q: "Where can I watch updates?",
    a: "Subscribe to the official SyrixScripts YouTube channel for update videos and showcases."
  }
];

export const socialsData = [
  {
    name: "YouTube",
    link: "https://youtube.com/@SyrixScripts",
  },
  {
    name: "Discord",
    link: "https://discord.gg/9MdzrvE9e9",
  },
];

export const chartDataGrowth = [
  { name: 'Jan', users: 4000, scripts: 2400 },
  { name: 'Feb', users: 3000, scripts: 1398 },
  { name: 'Mar', users: 2000, scripts: 9800 },
  { name: 'Apr', users: 2780, scripts: 3908 },
  { name: 'May', users: 1890, scripts: 4800 },
  { name: 'Jun', users: 2390, scripts: 3800 },
  { name: 'Jul', users: 3490, scripts: 4300 },
];
